import "./App.css";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import GridData from "./Components/GridData";
import Buttons from "./Components/Buttons";
import Add from "./Components/Add";
import Edit from "./Components/Edit";
import Delete from "./Components/Delete";
//import AdvanceSearch from "./Components/AdvanceSearch";
import { TextField } from "@mui/material";
//import DataTable from "./Components/DataTable";



function App() {
    return (
        <div className="App">
            <Header/>
            <GridData/>
            <Footer />
            
        </div>
    );
}

export default App;
