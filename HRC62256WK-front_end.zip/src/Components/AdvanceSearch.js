import { Button, CssBaseline, Dialog, DialogActions, DialogContent, DialogTitle, Grid, TextField } from '@mui/material';
import React from 'react';

const AdvanceSearch = () => {
const [open, setOpen] = React.useState(false);

const handleClickOpen = () => {
	setOpen(true);
};

const handleClose = () => {
	setOpen(false);
};



return (
	<div>
        <CssBaseline />
	<Button variant="outlined"
			color="primary" onClick={handleClickOpen} sx = {{width: "160px"}}>
		Advance Search
	</Button>
	<Dialog open={open} onClose={handleClose}
   PaperProps= {{
    style: {
      backgroundColor: "#283d4a",
      color: "#dddddd"
    },
  }}
  >
		<DialogTitle>
		Advance Search
		</DialogTitle>
		<DialogContent>
        <form
                method="post"
                action="http://localhost:8080/BACKEND/SearchServlet"
                id="addForm"
              >
                <TextField
                  id="outlined-basic"
                  label="Document Id"
                  variant="outlined"
                  name="doc_id"
                  style={{backgroundColor:"white"}}

                />
                <TextField
                  id="outlined-basic"
                  label="Customer Number"
                  variant="outlined"
                  name="cust_number"
                  style={{backgroundColor:"white"}}

                />
                <TextField
                  id="outlined-basic"
                  label="Invoice Id"
                  variant="outlined"
                  name="invoice_id"
                  style={{backgroundColor:"white"}}

                />
                <TextField
                  id="outlined-basic"
                  label="Business Year"
                  variant="outlined"
                  name="buisness_year"
                  style={{backgroundColor:"white"}}

                />
            </form>
		</DialogContent>
    <DialogActions>
          <Grid container>
            <Grid item xs = {12} md = {6} >
              <Button onClick={handleClose} color="primary" style = {{width: "100%"}}>
                CANCEL
              </Button>
            </Grid>
            <Grid item xs = {12} md = {6}>
              <Button onClick={handleClose} color="primary" autoFocus style = {{width: "100%"}}>
                SEARCH
              </Button>
            </Grid>
          </Grid>
          </DialogActions>
	</Dialog>
	</div>
);
}

export default AdvanceSearch;