import {
  Button,
  CssBaseline,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
} from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";

const baseURL = "http://localhost:8080/HRC40356W";
const Delete = () => {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    axios.get(baseURL + "/DeleteServlet").then((response) => {
      console.log(response.data);
    });
  }, []);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleYes = async () => {
    let res = axios.get(baseURL + "/DeleteServlet");
  };

  return (
    <div>
      <CssBaseline />
      <Button
        variant="outlined"
        color="primary"
        onClick={handleClickOpen}
        sx={{ width: "155px" }}
      >
        DELETE
      </Button>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>Delete Records ?</DialogTitle>
        <DialogContent>
          Are you sure you want to delete these record[s]?
        </DialogContent>
        <DialogActions>
          <Grid container>
            <Grid item xs={12} md={6}>
              <Button
                onClick={handleClose}
                color="primary"
                style={{ width: "100%" }}
              >
                CANCEL
              </Button>
            </Grid>
            <Grid item xs={12} md={6}>
              <Button
                onClick={handleYes}
                color="primary"
                autoFocus
                style={{ width: "100%" }}
              >
                DELETE
              </Button>
            </Grid>
          </Grid>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default Delete;
