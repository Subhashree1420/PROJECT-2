import { Typography } from "@mui/material";
import React from "react";

function Footer() {
    return (
        <footer
            style={{
                position: "relative",
                marginTop: "60px",
                textAlign: "center",
            }}
        >
            <Typography color={"white"} noWrap>
                <a
                    href="https://www.highradius.com/privacy-policy/"
                    target="_blank"
                    rel="noreferrer"
                >
                    Privacy Policy
                </a>{" "}
                | &copy; 2022 HighRadius Corporation. All Rights Reserved.
            </Typography>
        </footer>
    );
}

export default Footer;
