import React from "react";
import { Button } from "@mui/material";
import { Dialog } from "@mui/material";
import axios from 'axios';
import DialogActions from '@mui/material/DialogActions';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { ThemeProvider } from '@emotion/react';
import { CssBaseline, DialogContent, Grid, TextField } from '@mui/material';
export default function Buttons (props){

  
  const [deleteDisabledState,setDisableState]=React.useState(true);
  const [del,setDel]=React.useState(false);
  const handleClickDelete = () => {setDel(true)};
        const handleCloseDelete = () => {setDel(false)};
        const [data, setData] = React.useState(props.selected);

        const submitHandlerDelete = async (e) => {
          e.preventDefault();
      let val=props.selectionModel;
      console.log(val);
          let data = val.map((e, id) => {
            if(id == 0){
               return "sl_no=" + e;
            }
            else{
                return "&sl_no=" + e;
            }
       });
       
        
        let response = await axios.get("http://localhost:8080/BACKEND/DeleteServlet?" + data.join(''));
          if(response){
            setData([]);
            handleCloseDelete();
          }
      
        }
        const [open, setOpen] = React.useState(false);
        const [temp, setTemp] = React.useState(props.selectedData);
      

    const changeHandler = (e) => {
      const {name, value} = e.target;
      setTemp({...temp, [name]: value});
      //console.log(editData);
    }
const handleClickOpen = () => {
  //if(props.selectionData.length==1){
    setOpen(true);
    console.log(temp);

  //}
	
};
const submitHandler = async (e) => {
  e.preventDefault();

  let val = "sl_no=" + temp.sl_no + "&invoice_currency=" + temp.invoice_currency + "&cust_payment_terms=" + temp.cust_payment_terms;

let response = await axios.get("http://localhost:8080/BACKEND/Edit?" + val);


    if(response.data){
      handleClose();
    
  }
}

const handleClose = () => {
	setOpen(false);
};
  return (
    <>
   

                    <CssBaseline />
                    <Button variant="text"
			color="primary" onClick={handleClickOpen} sx = {{width: "155px"}}>
		Edit
	</Button>
	<Dialog open={open} onClose={handleClose}>
		<DialogTitle>
		EDIT
		</DialogTitle>
		<DialogContent>
        <form
                
                id="addForm"
              >
                <TextField
                  id="outlined-basic"
                  label="Inovice Currency"
                  variant="outlined"
                  name="invoice_currency"
                  value={temp.invoice_currency}
                  onChange={changeHandler}
                />
                <TextField
                  id="outlined-basic"
                  label="Customer Payment Terms"
                  variant="outlined"
                  name="cust_payment_terms"
                  value={temp.cust_payment_terms}
                  onChange={changeHandler}
                />
            </form>
		</DialogContent>
		<DialogActions>
          <Grid container>
            <Grid item xs = {12} md = {6} >
              <Button onClick={handleClose} color="primary" style = {{width: "100%"}}>
                CLOSE
              </Button>
            </Grid>
            <Grid item xs = {12} md = {6}>
              <Button onClick={submitHandler} color="primary" autoFocus style = {{width: "100%"}}>
                EDIT
              </Button>
            </Grid>
          </Grid>
          </DialogActions>
	</Dialog>
  <Button variant="outlined" onClick={handleClickDelete} disabled={false} style={{width:10 + 'vw', height:6 + 'vh'}}>DELETE</Button>
                    <Dialog open={del} maxWidth="sm" onClose={handleCloseDelete}>
                    <DialogTitle>Delete Records ?</DialogTitle>
          <DialogContentText>Are you sure you want to delete these record[s] ?</DialogContentText>
                    
          <DialogActions>
            <Button className='DeleteDialogFooterButtons' onClick={handleCloseDelete}>Cancel</Button>
            <Button className='DeleteDialogFooterButtons' onClick={submitHandlerDelete}>Delete</Button>
          </DialogActions>
                    </Dialog>
                    </>
  )
}