package com.highradius.backend;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class Advance
 */
@WebServlet("/Advance")
public class Advance extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Advance() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		List<Txn> list=new ArrayList<Txn>();
	     try {
	       Connection conn = JDBC.createConnect();
	       
	       PreparedStatement pst = conn.prepareStatement("select * from winter_internship"
	           + " where doc_id=? and invoice_id=? and cust_number=? and buisness_year=?; ");
	       pst.setString(1, request.getParameter("doc_id"));
	       pst.setString(2, request.getParameter("invoice_id"));
	       pst.setString(3, request.getParameter("cust_number"));
	       pst.setString(4, request.getParameter("buisness_year"));
	       System.out.println(pst);
	       ResultSet rs=pst.executeQuery(); 
	        while(rs.next()){  
	        	Txn client=new Txn();  
	              client.setSl_no(Integer.parseInt(rs.getString(1)));
	              client.setBusiness_code(rs.getString(2));
	              client.setCust_number(Long.parseLong(rs.getString(3)));  
	              client.setClear_date(rs.getString(4));  
	              client.setBuisness_year(rs.getInt(5));
	              client.setDoc_id(Long.parseLong(rs.getString(6)));
	              client.setPosting_date(rs.getString(7));
	              client.setDocument_create_date(rs.getString(8));
//	              client.setDocument_create_date1(rs.getString(9));
	              client.setDue_in_date(rs.getString(10));
	              client.setInvoice_currency(rs.getString(11));
	              client.setDocument_type(rs.getString(12));
	              client.setPosting_id(Integer.parseInt(rs.getString(13)));
//	              client.setArea_business(rs.getString(14));
	              client.setTotal_open_amount(Double.parseDouble(rs.getString(15)));
	              client.setBaseline_create_date(rs.getString(16));
	              client.setCust_payment_terms(rs.getString(17));
	              client.setInvoice_id(Long.parseLong(rs.getString(18)));
//	              client.setIsOpen(Integer.parseInt(rs.getString(19)));
//	              client.setAging_bucket(rs.getString(20));
//	              client.setIs_deleted(Integer.parseInt(rs.getString(21)));
	              
	              list.add(client);  
	          }  
	        
	        response.setContentType("application/json");
	           
	           Gson gson = new Gson();
	         String respData = gson.toJson(list);
//	         System.out.println(respData);
	         response.getWriter().print(respData);
	       
	       pst.close();
	       conn.close();
	     }catch(Exception e) {
	       e.printStackTrace();
	       }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
