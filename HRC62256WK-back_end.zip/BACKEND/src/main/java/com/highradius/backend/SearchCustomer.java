package com.highradius.backend;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class SearchCustomer
 */
@WebServlet("/SearchCustomer")
public class SearchCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Txn> res = new ArrayList<Txn>();
		
		try {
			Connection conn = JDBC.createConnect();
			String parameter = request.getParameter("customer_id");
			
			String query = "SELECT sl_no, business_code, cust_number, clear_date, buisness_year, doc_id,"
					+ "posting_date, document_create_date, due_in_date, invoice_currency, document_type,"
					+ "posting_id, total_open_amount, baseline_create_date, cust_payment_terms, invoice_id"
					+ " FROM winter_internship WHERE cust_number LIKE \'%" + parameter + "%\'";
			
			PreparedStatement pst = conn.prepareStatement(query);			
			ResultSet rs = pst.executeQuery();
			
			while(rs.next())
			{
				Txn d = new Txn();
				d.setSl_no(rs.getInt(1));
				d.setBusiness_code(rs.getString(2));
				d.setCust_number(rs.getLong(3));
				d.setClear_date(rs.getString(4));
				d.setBuisness_year(rs.getInt(5));
				d.setDoc_id(rs.getLong(6));
				d.setPosting_date(rs.getString(7));
				d.setDocument_create_date(rs.getString(8));
				d.setDue_in_date(rs.getString(9));
				d.setInvoice_currency(rs.getString(10));
				d.setDocument_create_date(rs.getString(11));
				d.setPosting_date(rs.getString(12));
				d.setTotal_open_amount(rs.getDouble(13));
				d.setBaseline_create_date(rs.getString(14));
				d.setCust_payment_terms(rs.getString(15));
				d.setInvoice_id(rs.getLong(16));
				
				res.add(d);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		Gson gson = new Gson();
		String respData = gson.toJson(res);
		
		response.getWriter().print(respData);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
