package com.highradius.backend;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class Edit
 */
@WebServlet("/Edit")
public class Edit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Edit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			HashMap<Object,Object>Response = new HashMap<Object,Object>(); 
			String slno= request.getParameter("sl_no");
			int sl_no= Integer.parseInt(slno);
			String invoice_currency = request.getParameter("invoice_currency");
			String cust_payment_terms = request.getParameter("cust_payment_terms");
		
		
		
		Connection con = JDBC.createConnect();
		String query = "UPDATE winter_internship SET  invoice_currency  = ?,cust_payment_terms  = ? WHERE sl_no = ?";
		
		PreparedStatement st = con.prepareStatement(query);
		st.setString(1,invoice_currency );
		st.setString(2, cust_payment_terms);
		st.setInt(3, sl_no);
		if(st.executeUpdate()>0) {
			Response.put("status", true);
		}
		else {
			Response.put("status", false);
		}
		Gson gson = new Gson();
		String ResponseJSON = gson.toJson(Response);
		try {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.getWriter().append(ResponseJSON);
		System.out.println(ResponseJSON);
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("exception occur");
		}
		con.close();
	}
	catch(Exception e) {
		e.printStackTrace();
		
	}
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
}
}	
		

