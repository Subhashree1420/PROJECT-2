package com.highradius.backend;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;




/**
 * Servlet implementation class FetchServlet
 */
@WebServlet("/fetch")
public class fetch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public fetch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//int row=10;
		try {
			//String pageIn=request.getParameter("page");
			//int page=Integer.parseInt(pageIn)*row;
			Connection conn = JDBC.createConnect();
			Statement s=conn.createStatement();
			String query = "SELECT sl_no,business_code,cust_number,clear_date,buisness_year,doc_id,posting_date,document_create_date,due_in_date,invoice_currency,document_type,posting_id,total_open_amount,baseline_create_date,cust_payment_terms,invoice_id from winter_internship WHERE is_deleted = 0";
			ResultSet rs = s.executeQuery(query);
			ArrayList<Txn> ALLData=new ArrayList<Txn>();
			while(rs.next()) {
				Txn t=new Txn();
				t.setSl_no(rs.getInt("sl_no"));
				t.setBusiness_code(rs.getString("business_code"));
				t.setCust_number(rs.getLong("cust_number"));
				t.setClear_date(rs.getString("clear_date"));
				t.setBuisness_year(rs.getInt("buisness_year"));
				t.setDoc_id(rs.getLong("doc_id"));
				t.setPosting_date(rs.getString("posting_date"));
				t.setDocument_create_date(rs.getString("document_create_date"));
				t.setDue_in_date(rs.getString("due_in_date"));
				t.setInvoice_currency(rs.getString("invoice_currency"));
				t.setDocument_type(rs.getString("document_type"));
				t.setPosting_id(rs.getInt("posting_id"));
				t.setTotal_open_amount(rs.getDouble("total_open_amount"));
				t.setBaseline_create_date(rs.getString("baseline_create_date"));
				t.setCust_payment_terms(rs.getString("cust_payment_terms"));
				t. setInvoice_id(rs.getLong("invoice_id"));
				ALLData.add(t);
			}
			/*for(Pojo stud: ALLData)
			 {
				 System.out.println(stud.toString());
			 }*/
			Gson gson = new GsonBuilder().serializeNulls().create();
			String dat=gson.toJson(ALLData);
			try {
				response.getWriter().write(dat); //getWriter() returns a PrintWriter object that can send character text to the client. 
			}
			catch(IOException e) {
				e.printStackTrace();
				System.out.println("exception occur");
			}
			rs.close();
			s.close();
			conn.close();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("exception occur");
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("exception occur");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
